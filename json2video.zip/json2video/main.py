from fastapi import FastAPI, Request
from fastapi.responses import FileResponse
from moviepy.editor import TextClip, concatenate_videoclips
import uuid
import os

app = FastAPI()

@app.post("/render")
async def render(request: Request):
    data = await request.json()
    template = data.get("template", [])
    clips = []

    for scene in template:
        text = scene.get("text", "")
        duration = scene.get("duration", 5)
        style = scene.get("style", {})
        font_size = style.get("font_size", 50)
        font_color = style.get("font_color", "white")
        bg_color = style.get("background_color", "black")

        clip = TextClip(text, fontsize=font_size, color=font_color, size=(1280, 720), bg_color=bg_color)
        clip = clip.set_duration(duration)
        clips.append(clip)

    final_clip = concatenate_videoclips(clips)
    filename = f"video_{uuid.uuid4().hex}.mp4"
    final_path = f"/tmp/{filename}"
    final_clip.write_videofile(final_path, fps=24)

    return FileResponse(final_path, media_type="video/mp4", filename=filename)
